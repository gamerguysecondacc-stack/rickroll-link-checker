import { ArrowUpRight, Link2 } from 'lucide-react'

const LIST_URL = 'https://github.com/Panic3564/rickroll-list/blob/main/rickrolls.json'

export function SiteHeader() {
  return (
    <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-8">
      <a href="/" className="flex items-center gap-3">
        <span className="flex size-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/25">
          <Link2 className="size-5" aria-hidden="true" />
        </span>
        <span className="text-lg font-semibold tracking-tight text-foreground">Rick Roll Checker</span>
      </a>
      <nav className="flex items-center gap-6">
        <a
          href="#generator"
          className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          Generator
        </a>
        <a
          href={LIST_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          Public list
          <ArrowUpRight className="size-4" aria-hidden="true" />
          <span className="sr-only">(opens in a new tab)</span>
        </a>
      </nav>
    </header>
  )
}
