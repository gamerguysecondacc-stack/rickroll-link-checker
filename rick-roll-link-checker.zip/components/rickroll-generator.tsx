'use client'

import { useState, useTransition } from 'react'
import { Check, Copy, Dices, ExternalLink, Loader2, Wand2 } from 'lucide-react'
import { GENERATOR_DOMAIN, GENERATOR_DOMAINS } from '@/lib/generator'
import { createRickrollLink } from '@/app/generator-actions'

export function RickrollGenerator() {
  const [path, setPath] = useState('')
  const [domain, setDomain] = useState(GENERATOR_DOMAIN)
  const [link, setLink] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [isPending, startTransition] = useTransition()

  function generate(input: string | null) {
    setError(null)
    setCopied(false)
    startTransition(async () => {
      const result = await createRickrollLink(input, domain)
      if (result.ok) {
        setPath(result.slug)
        setLink(result.link)
      } else {
        setLink(null)
        setError(result.error)
      }
    })
  }

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    generate(path.trim() ? path : null)
  }

  async function copyLink() {
    if (!link) return
    await navigator.clipboard.writeText(link)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <section
      id="generator"
      aria-labelledby="generator-title"
      className="w-full max-w-3xl scroll-mt-8 rounded-[2rem] border border-border bg-card p-6 shadow-xl shadow-foreground/5 sm:p-10"
    >
      <div className="mb-6 flex items-start gap-4">
        <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary">
          <Wand2 className="size-5" aria-hidden="true" />
        </span>
        <div>
          <h2 id="generator-title" className="text-xl font-bold tracking-tight text-foreground">
            Rick Roll Generator
          </h2>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
            Create an innocent-looking link that plays Never Gonna Give You Up when opened. Only links
            generated here will play.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <label htmlFor="domain" className="mb-3 block text-sm font-semibold text-foreground">
          Link domain
        </label>
        <select
          id="domain"
          value={domain}
          onChange={(event) => setDomain(event.target.value)}
          disabled={isPending}
          className="mb-5 h-12 w-full rounded-xl border border-input bg-background/60 px-3 text-base text-foreground outline-none transition-shadow focus:border-primary/50 focus:ring-4 focus:ring-primary/10 disabled:opacity-60"
        >
          {GENERATOR_DOMAINS.map((availableDomain) => (
            <option key={availableDomain} value={availableDomain}>
              {availableDomain}
            </option>
          ))}
        </select>

        <label htmlFor="slug" className="mb-3 block text-sm font-semibold text-foreground">
          Custom path <span className="font-normal text-muted-foreground">(optional)</span>
        </label>
        <div className="flex flex-col gap-3 rounded-2xl border border-input bg-background/60 p-2 transition-shadow focus-within:border-primary/50 focus-within:ring-4 focus-within:ring-primary/10 sm:flex-row sm:items-center">
          <div className="flex min-w-0 flex-1 items-center px-3">
            <span className="shrink-0 text-base text-muted-foreground">{domain}/</span>
            <input
              id="slug"
              name="slug"
              type="text"
              autoComplete="off"
              spellCheck={false}
              maxLength={120}
              value={path}
              onChange={(event) => setPath(event.target.value)}
              placeholder="files/vacation-photos.zip"
              aria-invalid={error ? true : undefined}
              aria-describedby={error ? 'slug-error' : undefined}
              className="h-12 w-full min-w-0 bg-transparent text-base text-foreground outline-none placeholder:text-muted-foreground/70"
            />
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              disabled={isPending}
              onClick={() => generate(null)}
              className="flex h-12 flex-1 items-center justify-center gap-2 rounded-xl border border-border bg-secondary px-4 font-semibold text-secondary-foreground transition-colors hover:bg-secondary/70 disabled:opacity-60 sm:flex-none"
            >
              <Dices className="size-5" aria-hidden="true" />
              Random
            </button>
            <button
              type="submit"
              disabled={isPending}
              className="flex h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-6 font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60 sm:flex-none"
            >
              {isPending ? (
                <Loader2 className="size-5 animate-spin" aria-hidden="true" />
              ) : (
                <Wand2 className="size-5" aria-hidden="true" />
              )}
              {isPending ? 'Creating' : 'Generate'}
            </button>
          </div>
        </div>
      </form>

      <div aria-live="polite">
        {error && (
          <p id="slug-error" className="mt-4 text-sm font-medium text-destructive">
            {error}
          </p>
        )}
        {link && (
          <div className="mt-6 rounded-2xl border border-primary/20 bg-primary/5 p-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-primary">Your link</p>
            <div className="mt-2 flex flex-col gap-3 sm:flex-row sm:items-center">
              <code className="min-w-0 flex-1 break-all font-mono text-sm text-foreground">{link}</code>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={copyLink}
                  className="flex h-10 items-center gap-2 rounded-lg bg-foreground px-4 text-sm font-semibold text-background transition-opacity hover:opacity-90"
                >
                  {copied ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
                <a
                  href={link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-10 items-center gap-2 rounded-lg border border-border bg-card px-4 text-sm font-semibold text-foreground transition-colors hover:bg-secondary"
                >
                  <ExternalLink className="size-4" aria-hidden="true" />
                  Test
                  <span className="sr-only">(opens in a new tab)</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
