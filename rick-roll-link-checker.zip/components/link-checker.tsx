'use client'

import { useActionState } from 'react'
import { CircleHelp, Loader2, Search, ShieldCheck } from 'lucide-react'
import { checkLinkAction } from '@/app/actions'
import { CheckResultCard } from '@/components/check-result'

export function LinkChecker() {
  const [result, formAction, isPending] = useActionState(checkLinkAction, null)

  return (
    <section className="w-full max-w-3xl rounded-[2rem] border border-border bg-card p-6 shadow-xl shadow-foreground/5 sm:p-10">
      <form action={formAction}>
        <label htmlFor="url" className="mb-3 block text-sm font-semibold text-foreground">
          URL to check
        </label>
        <div className="flex flex-col gap-3 rounded-2xl border border-input bg-background/60 p-2 transition-shadow focus-within:border-primary/50 focus-within:ring-4 focus-within:ring-primary/10 sm:flex-row sm:items-center">
          <div className="flex flex-1 items-center gap-3 px-3">
            <Search className="size-5 shrink-0 text-muted-foreground" aria-hidden="true" />
            <input
              id="url"
              name="url"
              type="text"
              inputMode="url"
              autoComplete="off"
              spellCheck={false}
              required
              maxLength={2048}
              defaultValue={result?.input}
              placeholder="https://example.com/a-link"
              className="h-12 w-full bg-transparent text-base text-foreground outline-none placeholder:text-muted-foreground/70"
            />
          </div>
          <button
            type="submit"
            disabled={isPending}
            className="flex h-12 items-center justify-center gap-2 rounded-xl bg-primary px-6 font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-70"
          >
            {isPending ? (
              <Loader2 className="size-5 animate-spin" aria-hidden="true" />
            ) : (
              <ShieldCheck className="size-5" aria-hidden="true" />
            )}
            {isPending ? 'Checking…' : 'Check link'}
          </button>
        </div>
      </form>

      <div aria-live="polite">{result && !isPending && <CheckResultCard result={result} />}</div>

      <div className="mt-8 border-t border-dashed border-border pt-8">
        <div className="flex gap-4">
          <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
            <CircleHelp className="size-5" aria-hidden="true" />
          </span>
          <div>
            <h2 className="font-semibold text-foreground">What gets checked?</h2>
            <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
              Your URL is compared with entries in the public list. A missing match is not a safety guarantee.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
