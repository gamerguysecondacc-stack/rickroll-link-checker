import { CircleAlert, ShieldAlert, ShieldCheck } from 'lucide-react'
import type { CheckResult } from '@/lib/rickroll'

export function CheckResultCard({ result }: { result: CheckResult }) {
  if (result.status === 'error') {
    return (
      <div className="mt-6 flex gap-4 rounded-2xl border border-border bg-secondary/60 p-5">
        <CircleAlert className="mt-0.5 size-5 shrink-0 text-muted-foreground" aria-hidden="true" />
        <p className="text-sm text-foreground">{result.message}</p>
      </div>
    )
  }

  if (result.status === 'rickroll') {
    return (
      <div className="mt-6 flex gap-4 rounded-2xl border border-destructive/30 bg-destructive/10 p-5">
        <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-destructive text-white">
          <ShieldAlert className="size-5" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <h3 className="font-semibold text-destructive">Rick roll detected!</h3>
          <p className="mt-1 text-sm text-foreground">
            This link got flagged as a Rick Roll!
          </p>
          <p className="mt-3 truncate rounded-lg bg-card px-3 py-2 font-mono text-xs text-muted-foreground">
            Matched: {result.match}
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="mt-6 flex gap-4 rounded-2xl border border-success/30 bg-success/10 p-5">
      <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-success text-white">
        <ShieldCheck className="size-5" aria-hidden="true" />
      </span>
      <div className="min-w-0">
        <h3 className="font-semibold text-success">No match found</h3>
        <p className="mt-1 text-sm text-foreground">
          {`This link isn't in the public list of ${result.listSize} known rick rolls. Still, stay alert.`}
        </p>
      </div>
    </div>
  )
}
