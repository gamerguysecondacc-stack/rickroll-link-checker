'use server'

import { db } from '@/lib/db'
import { rickrollLinks } from '@/lib/db/schema'
import { GENERATOR_DOMAIN, buildLink, isGeneratorDomain, randomSlug, sanitizeSlug } from '@/lib/generator'

export type CreateLinkResult =
  | { ok: true; slug: string; link: string }
  | { ok: false; error: string }

async function insertSlug(slug: string) {
  const inserted = await db
    .insert(rickrollLinks)
    .values({ slug })
    .onConflictDoNothing()
    .returning({ slug: rickrollLinks.slug })
  return inserted.length > 0
}

export async function createRickrollLink(input: string | null, domain = GENERATOR_DOMAIN): Promise<CreateLinkResult> {
  try {
    if (typeof domain !== 'string' || !isGeneratorDomain(domain)) {
      return { ok: false, error: 'Please choose a valid domain.' }
    }

    if (input !== null) {
      if (typeof input !== 'string' || input.length > 500) {
        return { ok: false, error: 'Please enter a valid path.' }
      }
      const slug = sanitizeSlug(input)
      if (!slug) return { ok: false, error: 'Please enter a valid path.' }
      if (!(await insertSlug(slug))) {
        return { ok: false, error: 'That path is already taken. Try another one.' }
      }
      return { ok: true, slug, link: buildLink(slug, domain) }
    }

    for (let attempt = 0; attempt < 5; attempt++) {
      const slug = randomSlug()
      if (await insertSlug(slug)) return { ok: true, slug, link: buildLink(slug, domain) }
    }
    return { ok: false, error: 'Could not generate a unique link. Please try again.' }
  } catch (error) {
    console.error('[rickroll] Failed to create link:', error)
    return { ok: false, error: 'Something went wrong while saving your link.' }
  }
}
