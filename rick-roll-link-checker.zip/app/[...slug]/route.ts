import { eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { rickrollLinks } from '@/lib/db/schema'

const RICKROLL_GIF_URL = 'https://media.giphy.com/media/Ju7l5y9osyymQ/giphy.gif'

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Loading...</title>
<style>
  html, body { margin: 0; height: 100%; background: #000; }
  body { display: flex; align-items: center; justify-content: center; }
  img { width: 100vw; height: 100vh; object-fit: contain; }
</style>
</head>
<body>
<img src="${RICKROLL_GIF_URL}" alt="Rick Astley dancing - you just got Rick Rolled">
</body>
</html>`

const FALLBACK_URL = 'https://rickroll-link-checker.vercel.app'

async function linkExists(slug: string) {
  if (!slug || slug.length > 120) return false
  try {
    const rows = await db
      .select({ slug: rickrollLinks.slug })
      .from(rickrollLinks)
      .where(eq(rickrollLinks.slug, slug))
      .limit(1)
    return rows.length > 0
  } catch (error) {
    console.error('[rickroll] Link lookup failed:', error)
    return false
  }
}

export async function GET(_request: Request, { params }: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await params
  if (!(await linkExists(slug.join('/')))) {
    return Response.redirect(FALLBACK_URL, 307)
  }

  return new Response(html, {
    status: 200,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store',
    },
  })
}
