import { LinkChecker } from '@/components/link-checker'
import { RickrollGenerator } from '@/components/rickroll-generator'
import { SiteHeader } from '@/components/site-header'

export default function Page() {
  return (
    <div className="relative min-h-screen overflow-hidden">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-[-20rem] size-[60rem] -translate-x-1/2 rounded-full bg-[radial-gradient(circle,oklch(0.95_0.04_80)_0%,transparent_65%)]"
      />
      <div className="relative">
        <SiteHeader />
        <main className="mx-auto flex w-full max-w-6xl flex-col items-center px-6 pb-24 pt-12 sm:pt-20">
          <h1 className="text-center text-6xl font-extrabold leading-[0.95] tracking-[-0.06em] sm:text-8xl lg:text-9xl">
            <span className="block text-foreground">Rick Roll</span>
            <span className="block text-primary">Link Checker</span>
          </h1>
          <p className="mt-8 text-center text-lg text-muted-foreground sm:text-xl">The Link gets compared to a public list</p>
          <div className="mt-14 flex w-full justify-center">
            <LinkChecker />
          </div>
          <div className="mt-10 flex w-full justify-center">
            <RickrollGenerator />
          </div>
        </main>
      </div>
    </div>
  )
}
