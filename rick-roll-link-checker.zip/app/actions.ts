'use server'

import { checkLink, type CheckResult } from '@/lib/rickroll'

export async function checkLinkAction(_prev: CheckResult | null, formData: FormData): Promise<CheckResult> {
  const url = formData.get('url')
  if (typeof url !== 'string' || url.length > 2048) {
    return { status: 'error', input: '', message: 'Please enter a valid URL.' }
  }
  return checkLink(url)
}
