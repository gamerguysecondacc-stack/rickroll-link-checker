import { NextResponse, type NextRequest } from 'next/server'
import { GENERATOR_DOMAIN } from '@/lib/generator'

const FALLBACK_URL = 'https://rickroll-link-checker.vercel.app'

export function proxy(request: NextRequest) {
  const host = request.headers.get('host')?.split(':')[0]
  if (host === GENERATOR_DOMAIN) {
    return NextResponse.redirect(FALLBACK_URL, 307)
  }
  return NextResponse.next()
}

export const config = {
  matcher: '/',
}
