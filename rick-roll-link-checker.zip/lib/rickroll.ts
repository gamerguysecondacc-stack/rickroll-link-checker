const RAW_LIST_URL = 'https://raw.githubusercontent.com/Panic3564/rickroll-list/main/rickrolls.json'

const YOUTUBE_HOSTS = new Set(['youtube.com', 'youtu.be', 'youtube-nocookie.com', 'music.youtube.com'])

type NormalizedLink = {
  host: string
  path: string
  key: string
  youtubeId: string | null
}

export type CheckResult =
  | { status: 'rickroll'; input: string; match: string; listSize: number }
  | { status: 'clean'; input: string; listSize: number }
  | { status: 'error'; input: string; message: string }

async function getList(): Promise<string[]> {
  const res = await fetch(RAW_LIST_URL, { next: { revalidate: 3600 } })
  if (!res.ok) throw new Error(`List request failed with ${res.status}`)
  const data = (await res.json()) as { rickrolls?: unknown }
  if (!Array.isArray(data.rickrolls)) throw new Error('Unexpected list format')
  return data.rickrolls.filter((entry): entry is string => typeof entry === 'string')
}

function normalize(raw: string): NormalizedLink | null {
  const trimmed = raw.trim()
  if (!trimmed) return null
  const withProtocol = /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`

  let url: URL
  try {
    url = new URL(withProtocol)
  } catch {
    return null
  }
  if (!url.hostname.includes('.')) return null

  const host = url.hostname.toLowerCase().replace(/^(www\.|m\.)/, '')
  const path = url.pathname.replace(/\/+$/, '')
  const query = url.search

  return {
    host,
    path,
    key: `${host}${path}${query}`,
    youtubeId: extractYoutubeId(host, url),
  }
}

function extractYoutubeId(host: string, url: URL): string | null {
  if (!YOUTUBE_HOSTS.has(host)) return null
  if (host === 'youtu.be') return url.pathname.split('/')[1] || null

  const fromQuery = url.searchParams.get('v') ?? url.searchParams.get('video_id')
  if (fromQuery) return fromQuery

  const match = url.pathname.match(/^\/(?:shorts|embed|live|v)\/([\w-]+)/)
  return match?.[1] ?? null
}

function matches(input: NormalizedLink, entry: NormalizedLink) {
  if (input.youtubeId && entry.youtubeId) return input.youtubeId === entry.youtubeId
  if (input.host !== entry.host) return false
  if (!entry.path && !entry.key.includes('?')) return true
  if (input.key === entry.key) return true
  return input.path === entry.path && !entry.key.includes('?')
}

export async function checkLink(raw: string): Promise<CheckResult> {
  const input = raw.trim()
  const normalized = normalize(input)
  if (!normalized) {
    return { status: 'error', input, message: 'Please enter a valid URL, e.g. https://example.com/a-link' }
  }

  let list: string[]
  try {
    list = await getList()
  } catch {
    return { status: 'error', input, message: 'The public list could not be loaded. Please try again in a moment.' }
  }

  for (const entry of list) {
    const normalizedEntry = normalize(entry)
    if (normalizedEntry && matches(normalized, normalizedEntry)) {
      return { status: 'rickroll', input, match: entry, listSize: list.length }
    }
  }

  return { status: 'clean', input, listSize: list.length }
}
