export const GENERATOR_DOMAIN = 'cloud-downloads.vercel.app'

export const GENERATOR_DOMAINS = [
  GENERATOR_DOMAIN,
  'password-generator-tool-page.vercel.app',
  'qr-generating-tool.vercel.app',
  'hosted-files-system.vercel.app',
  'file-dist.vercel.app',
] as const

export type GeneratorDomain = (typeof GENERATOR_DOMAINS)[number]

export function isGeneratorDomain(value: string): value is GeneratorDomain {
  return GENERATOR_DOMAINS.includes(value as GeneratorDomain)
}

const DECOY_NAMES = [
  'files/project-final-v2.zip',
  'shared/holiday-photos-2026',
  'docs/meeting-notes.pdf',
  'download/installer-setup.exe',
  'share/presentation-deck.pptx',
  'files/homework-solutions.pdf',
  'media/concert-recording.mp4',
  'shared/budget-spreadsheet.xlsx',
]

function randomId(length = 6) {
  const alphabet = 'abcdefghijkmnpqrstuvwxyz23456789'
  const bytes = crypto.getRandomValues(new Uint8Array(length))
  return Array.from(bytes, (byte) => alphabet[byte % alphabet.length]).join('')
}

export function randomSlug() {
  const name = DECOY_NAMES[Math.floor(Math.random() * DECOY_NAMES.length)]
  const slash = name.indexOf('/')
  return `${name.slice(0, slash)}/${randomId()}/${name.slice(slash + 1)}`
}

export function sanitizeSlug(input: string) {
  return input
    .trim()
    .replace(/^https?:\/\/[^/]+/i, '')
    .replace(/\s+/g, '-')
    .replace(/[^a-zA-Z0-9\-_.~/]/g, '')
    .replace(/\/{2,}/g, '/')
    .replace(/^\/+|\/+$/g, '')
    .slice(0, 120)
}

export function buildLink(slug: string, domain: string = GENERATOR_DOMAIN) {
  const selectedDomain = isGeneratorDomain(domain) ? domain : GENERATOR_DOMAIN
  return `https://${selectedDomain}/${slug}`
}
