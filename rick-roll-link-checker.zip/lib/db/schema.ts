import { pgTable, text, timestamp } from 'drizzle-orm/pg-core'

export const rickrollLinks = pgTable('rickroll_links', {
  slug: text('slug').primaryKey(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})
